# WorkBuddy 每日签到（自动签到）

在 1.2.26 基线上补齐 WorkBuddy（国内版 `copilot.tencent.com`）的每日签到，模式对齐官方 App：
启动补签 + 每天 9:00 / 21:00 自动补签（对应官方 `checkin_hours = 9,21`）+ 面板手动补一刀/看状态。

## 一、改了哪些文件

| 文件 | 改动 |
| --- | --- |
| `app/src/main/java/com/gaeul/allin/WorkBuddyCheckin.java` | 新增。封装 `POST {origin}/v2/billing/meter/daily-checkin`，body `{}`，鉴权头复用 `WorkBuddyPolicy.catalogHeaders`（与额度查询同一套账号头）；幂等，`code==0` 或返回“已签到”都判成功 |
| `app/src/main/java/com/gaeul/allin/GatewayServer.java` | 新增路由 `/api/workbuddy/checkin`（POST，body `{"accountId":""}` 空=全部）与 `/api/workbuddy/checkin-status`（GET）；新增 `startWorkBuddyCheckinScheduler` / `autoCheckinWorkBuddy` / `workBuddyCheckinAccount` / `persistWorkBuddyCheckin`；启动补签一次 + 每 30 分钟看表命中 9/21 点补签；`stop()` 里关闭调度线程 |
| `app/src/main/assets/dashboard.html` | WorkBuddy 卡片加「每日签到 / 签到状态」按钮与状态行；新增 `workbuddyCheckinAction()` |
| `app/build.gradle` | versionCode 32→33，versionName `1.2.26-test`→`1.2.27-test`（便于覆盖安装） |

## 二、用到的上游接口（与官方客户端一致）

```
POST https://copilot.tencent.com/v2/billing/meter/daily-checkin
Authorization: Bearer <账号 access token>（其余账号头由 WorkBuddyPolicy.catalogHeaders 生成）
Content-Type: application/json

{}
```

- 幂等：当天签过返回“今天已签到”，重复调用不报错、不扣积分。
- 只有国内版有签到体系；国际版 `workbuddy-ai`（www.workbuddy.ai）没有，直接跳过/拒绝。

## 三、面板接口

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| POST | `/api/workbuddy/checkin` | body `{"accountId":""}`，空=全部启用账号；返回每账号 `ok/already/code/msg` |
| GET | `/api/workbuddy/checkin-status` | 每账号今日是否已签、最近结果 |
| GET | `/api/providers/billing?provider=workbuddy` | 已有接口，返回剩余额度（credits） |

签到结果写回配置对应账号：`checkinDate` / `checkinOutcome`（`ok`/`already`/`failed`）/ `checkinMessage` / `checkinAt`，重启不丢。

## 四、自动签到

- 网关启动后立即补签一次（当天已签的账号跳过）。
- 常驻调度每 30 分钟看一次表，命中 **9 点 / 21 点** 各补一次，落地按设备本地时区。
- 调度线程 daemon、随 `stop()` 关闭；只起一次（字段守卫），服务重启不叠加。
- 失败只记 `checkinOutcome=failed`，不影响模型调用。

## 五、验收

```bash
KEY=<管理口令>
curl -s -X POST http://127.0.0.1:3425/api/workbuddy/checkin \
     -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" -d '{}'
curl -s "http://127.0.0.1:3425/api/workbuddy/checkin-status" -H "Authorization: Bearer $KEY"
```

1. 面板 WorkBuddy 卡片出现「每日签到 / 签到状态」。
2. 点「每日签到」→ 当天首次返回「签到成功」，再点返回「今日已签到」（幂等）。
3. 重启 App 再点，`checkinDate` 保留，当天不会重复签。

## 六、构建

基线是官方 `xunianooo/All-in` v1.2.26-test。用官方签名（`build-signed.py`，证书 SHA-256 `34618e7f…`）可直接覆盖安装；
用其它 keystore（如 `magpie.keystore`，SHA-256 `d4c55385…`）签名则是不同证书，**必须先在手机上备份配置再卸载旧版**才能装。
