# WorkBuddy 多账号 · 额度 · 每日签到

把 WorkBuddy（腾讯云代码助手 / CodeBuddy）的三件事补进 All In：账号池、额度查看、每日签到。

## 一、改了什么

| 文件 | 改动 |
| --- | --- |
| `app/src/main/java/com/gaeul/allin/WorkBuddyAccounts.java` | 新增。签到与额度两条上游接口的封装：`normalizeToken` / `baseOf` / `checkin` / `usage` |
| `app/src/main/java/com/gaeul/allin/GatewayServer.java` | `fetchBillingAllowance` 增加 `case "workbuddy"`；新增 `/api/workbuddy/checkin`、`/api/workbuddy/status`；新增 `workBuddyCheckin` / `workBuddyStatus` / `autoCheckinWorkBuddy` / `startWorkBuddyCheckinLoop`；启动时补签一次 + 9/21 点轮询 |
| `app/src/main/assets/dashboard.html` | WorkBuddy 卡片加「签到账号」下拉 + 「查看积分」+「每日签到」+ 状态行；`refreshProviderBadges` 同步刷新下拉 |
| `.github/workflows/build-apk.yml` | 新增。push 即出 APK（Actions → Artifacts） |
| `scripts/build-workbuddy-apk.sh` | 新增。本地一条命令编译，自动生成 keystore |

## 二、用到的上游接口（与官方客户端一致）

```
POST {base}/v2/billing/meter/daily-checkin       body {}        → 签到，幂等（当天重复回「今天已签到」）
POST {base}/v2/billing/meter/get-user-resource   body {}        → 资源包与剩余额度 CapacityRemain（credits）
```

- `Authorization: Bearer <token>`，token 支持 JWT（`eyJ...`）或 `COSY.` 前缀，粘 `Bearer ` 前缀会自动剥掉。
- `base` 取自账号的 `domain` / `baseUrl` / `origin`；缺省按 `region` 判：`domestic → https://www.codebuddy.cn`，`international → https://www.workbuddy.ai`。
- 国际版没有每日签到体系，账号标了 international 时签到直接跳过，只刷额度。

## 三、面板接口

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| POST | `/api/workbuddy/checkin` | body `{"accountId":""}`，空=全部启用账号；返回每账号 `ok/already/msg/remaining/packages` |
| GET | `/api/workbuddy/status?refresh=1` | 每账号签到日期、今日是否已签、剩余积分；`refresh=1` 实时拉一次上游 |
| GET | `/api/providers/billing` | 已有接口，WorkBuddy 现在会返回 `{kind:"allowance",unit:"credits",remaining:N}` |

签到结果会写回配置里对应账号：`checkinDate` / `checkinOutcome`（`ok` / `already` / `failed`）/ `checkinAt` / `creditsRemaining` / `creditsObservedAt`，重启不丢。

## 四、自动签到

- 网关启动后立刻补签一次（当天已签的账号跳过）。
- 常驻线程每 30 分钟看一次表，命中 **9 点 / 21 点** 各补一次（对齐官方 `checkin_hours = 9,21`），设备本地时区。
- 线程只起一次（`workBuddyLoopStarted` 守卫），服务重启不会叠加。
- 失败不改 `checkinDate` 之外的任何东西，也不影响模型调用。

## 五、验收

1. 装好后进面板，WorkBuddy 卡片应出现「签到账号 / 查看积分 / 每日签到」一行。
2. 点「查看积分」→ 状态行显示每个账号的 `今日已签/未签到 · 积分 N`，末尾合计。
3. 点「每日签到」→ 当天首次返回「签到成功」，再点返回「今日已签到」（幂等）。
4. curl 侧验证：
   ```bash
   curl -s -X POST http://127.0.0.1:3425/api/workbuddy/checkin \
        -H "Authorization: Bearer $MAGPIE_KEY" -H "Content-Type: application/json" -d '{}'
   curl -s "http://127.0.0.1:3425/api/workbuddy/status?refresh=1" \
        -H "Authorization: Bearer $MAGPIE_KEY"
   ```
5. 重启 App 后再看，`checkinDate` 保留，当天不会重复签。

## 六、构建

```bash
# 本地
bash scripts/build-workbuddy-apk.sh

# 云端
git push 后到 Actions → Build APK → Artifacts 取 AllIn-apk
```
