package com.gaeul.allin;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * WorkBuddy（腾讯云代码助手 / CodeBuddy）账号级能力：每日签到与积分查询。
 *
 * 对齐官方客户端的两条接口：
 *   POST {base}/v2/billing/meter/daily-checkin      签到，body 为 {}，当天重复调用幂等（回「已签到」）
 *   POST {base}/v2/billing/meter/get-user-resource  资源包列表与剩余额度（CapacityRemain，单位 credits）
 *
 * 国内版 base 默认 https://www.codebuddy.cn；国际版 https://www.workbuddy.ai 没有每日签到体系，
 * 走签到只会拿到「国际版积分由上游自动发放」这类无副作用结果，所以 {@link #isInternational} 先挡一层。
 */
public final class WorkBuddyAccounts {

    public static final String DOMESTIC_BASE = "https://www.codebuddy.cn";
    public static final String INTL_BASE = "https://www.workbuddy.ai";
    public static final String CHECKIN_PATH = "/v2/billing/meter/daily-checkin";
    public static final String RESOURCE_PATH = "/v2/billing/meter/get-user-resource";

    private static final String UA =
            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) "
                    + "Chrome/125.0 Mobile Safari/537.36";
    private static final int CONNECT_TIMEOUT_MS = 15000;
    private static final int READ_TIMEOUT_MS = 20000;

    private WorkBuddyAccounts() {
    }

    /** 去掉 Bearer 前缀；粘贴整段 JSON 时取 accessToken/token/access_token。 */
    public static String normalizeToken(String raw) {
        if (raw == null) return "";
        String t = raw.trim();
        if (t.isEmpty()) return "";
        if (t.charAt(0) == '{') {
            try {
                JSONObject j = new JSONObject(t);
                String[] keys = new String[]{"accessToken", "access_token", "token", "access"};
                for (int i = 0; i < keys.length; i++) {
                    String v = j.optString(keys[i], "");
                    if (!v.isEmpty()) {
                        t = v.trim();
                        break;
                    }
                }
            } catch (Exception ignored) {
            }
        }
        if (t.regionMatches(true, 0, "Bearer ", 0, 7)) t = t.substring(7).trim();
        return t;
    }

    /**
     * 解析用户粘贴的凭据：纯 token、带 Bearer 前缀、或整段导出 JSON
     * （{@code {"auth":{"accessToken":...,"domain":"www.codebuddy.cn"},"region":"domestic"}}）。
     * 返回 {token, domain?, region?}，domain 已规范成 https://host。
     */
    public static JSONObject parseCredential(String raw) {
        JSONObject out = new JSONObject();
        try {
            String token = normalizeToken(raw);
            out.put("token", token);
            if (raw == null) return out;
            String text = raw.trim();
            if (!text.startsWith("{")) return out;
            JSONObject j = new JSONObject(text);
            JSONObject auth = j.optJSONObject("auth");
            String region = j.optString("region", "");
            String domain = "";
            if (auth != null) {
                domain = auth.optString("domain", "");
                if (region.isEmpty()) region = auth.optString("region", "");
            }
            if (domain.isEmpty()) domain = j.optString("domain", j.optString("baseUrl", ""));
            if (!region.isEmpty()) out.put("region", region);
            if (!domain.isEmpty()) {
                JSONObject probe = new JSONObject();
                probe.put("domain", domain);
                if (!region.isEmpty()) probe.put("region", region);
                out.put("domain", baseOf(probe));
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    /** 账号里记录了 domain/baseUrl 就用它，否则按 region 判国内/国际。 */
    public static String baseOf(JSONObject account) {
        String domain = "";
        if (account != null) {
            domain = account.optString("domain", "");
            if (domain.isEmpty()) domain = account.optString("baseUrl", "");
            if (domain.isEmpty()) domain = account.optString("origin", "");
        }
        domain = domain.trim();
        if (domain.isEmpty()) return isInternational(account) ? INTL_BASE : DOMESTIC_BASE;
        if (!domain.startsWith("http://") && !domain.startsWith("https://")) {
            domain = "https://" + domain;
        }
        while (domain.endsWith("/")) domain = domain.substring(0, domain.length() - 1);
        int cut = domain.indexOf("/v2/");
        if (cut > 0) domain = domain.substring(0, cut);
        return domain;
    }

    public static boolean isInternational(JSONObject account) {
        if (account == null) return false;
        String region = account.optString("region", "");
        if ("international".equalsIgnoreCase(region) || "global".equalsIgnoreCase(region)) return true;
        String base = account.optString("domain", account.optString("baseUrl", ""));
        return base.toLowerCase().contains("workbuddy.ai");
    }

    /**
     * 签到。返回字段：ok / http / code / msg / already / credit / base。
     * 当天已签到按成功处理（幂等），不算失败。
     */
    public static JSONObject checkin(String token, String base) {
        JSONObject out = new JSONObject();
        String tk = normalizeToken(token);
        try {
            out.put("base", base == null ? "" : base);
            if (tk.isEmpty()) {
                out.put("ok", false);
                out.put("msg", "账号缺少 token");
                return out;
            }
            Reply reply = post(base + CHECKIN_PATH, tk, "{}");
            out.put("http", reply.code);
            String msg = reply.body;
            int code = -1;
            double credit = 0;
            boolean hasCredit = false;
            try {
                JSONObject j = new JSONObject(reply.body);
                code = j.optInt("code", j.optInt("errorCode", -1));
                String m = j.optString("msg", "");
                if (m.isEmpty()) m = j.optString("message", "");
                if (!m.isEmpty()) msg = m;
                JSONObject data = j.optJSONObject("data");
                if (data != null) {
                    credit = data.optDouble("credit", data.optDouble("credits", 0));
                    hasCredit = data.has("credit") || data.has("credits");
                }
            } catch (Exception ignored) {
            }
            boolean already = msg != null && (msg.contains("已签到") || msg.toLowerCase().contains("already"));
            boolean ok = already || code == 0 || (reply.code >= 200 && reply.code < 300);
            out.put("ok", ok);
            out.put("already", already);
            out.put("code", code);
            out.put("msg", msg == null ? "" : msg);
            if (hasCredit) out.put("credit", credit);
            return out;
        } catch (Exception e) {
            try {
                out.put("ok", false);
                out.put("msg", String.valueOf(e.getMessage()));
            } catch (Exception ignored) {
            }
            return out;
        }
    }

    /**
     * 积分/资源包查询。返回：ok / remaining / size / packages / accounts[] / msg。
     */
    public static JSONObject usage(String token, String base) {
        JSONObject out = new JSONObject();
        String tk = normalizeToken(token);
        try {
            out.put("base", base == null ? "" : base);
            if (tk.isEmpty()) {
                out.put("ok", false);
                out.put("msg", "账号缺少 token");
                return out;
            }
            Reply reply = post(base + RESOURCE_PATH, tk, "{}");
            JSONObject j = new JSONObject(reply.body.isEmpty() ? "{}" : reply.body);
            int code = j.optInt("code", -1);
            if (code != 0) {
                out.put("ok", false);
                out.put("http", reply.code);
                out.put("msg", j.optString("msg", j.optString("error", "HTTP " + reply.code)));
                return out;
            }
            JSONObject data = j.optJSONObject("data");
            JSONObject response = data == null ? null : data.optJSONObject("Response");
            JSONObject payload = response == null ? null : response.optJSONObject("Data");
            if (payload == null) payload = data;
            if (payload == null) {
                out.put("ok", false);
                out.put("msg", "响应缺少 data");
                return out;
            }
            JSONArray accounts = payload.optJSONArray("Accounts");
            double remain = 0;
            double size = 0;
            JSONArray packets = new JSONArray();
            for (int i = 0; accounts != null && i < accounts.length(); i++) {
                JSONObject a = accounts.optJSONObject(i);
                if (a == null) continue;
                remain += a.optDouble("CapacityRemain", 0);
                size += a.optDouble("CapacitySize", 0);
                JSONObject one = new JSONObject();
                one.put("name", a.optString("PackageName", a.optString("SubProductName", "")));
                one.put("remain", a.optDouble("CapacityRemain", 0));
                one.put("size", a.optDouble("CapacitySize", 0));
                one.put("cycleEnd", a.optString("CycleEndTime", ""));
                packets.put(one);
            }
            out.put("ok", true);
            out.put("remaining", remain);
            out.put("size", size);
            out.put("packages", packets.length());
            out.put("accounts", packets);
            out.put("msg", "OK");
            return out;
        } catch (Exception e) {
            try {
                out.put("ok", false);
                out.put("msg", String.valueOf(e.getMessage()));
            } catch (Exception ignored) {
            }
            return out;
        }
    }

    private static final class Reply {
        final int code;
        final String body;

        Reply(int code, String body) {
            this.code = code;
            this.body = body == null ? "" : body;
        }
    }

    private static Reply post(String url, String token, String body) throws IOException {
        HttpURLConnection conn = NetworkPolicy.openHttp(url);
        try {
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(CONNECT_TIMEOUT_MS);
            conn.setReadTimeout(READ_TIMEOUT_MS);
            Map<String, String> headers = new LinkedHashMap<String, String>();
            headers.put("User-Agent", UA);
            headers.put("Content-Type", "application/json");
            headers.put("Accept", "application/json, text/plain, */*");
            headers.put("X-Requested-With", "XMLHttpRequest");
            headers.put("X-Product", "SaaS");
            headers.put("X-Agent-Intent", "craft");
            headers.put("X-Agent-Purpose", "conversation");
            headers.put("X-Agent-Type", "main");
            headers.put("X-Auth-Refresh-Source", "workbuddy");
            headers.put("Authorization", "Bearer " + token);
            Iterator<Map.Entry<String, String>> it = headers.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, String> e = it.next();
                conn.setRequestProperty(e.getKey(), e.getValue());
            }
            OutputStream os = conn.getOutputStream();
            os.write(body.getBytes("UTF-8"));
            os.flush();
            os.close();
            int code = conn.getResponseCode();
            InputStream is = code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream();
            return new Reply(code, readAll(is));
        } finally {
            try {
                conn.disconnect();
            } catch (Exception ignored) {
            }
        }
    }

    private static String readAll(InputStream in) throws IOException {
        if (in == null) return "";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        try {
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } finally {
            try {
                in.close();
            } catch (Exception ignored) {
            }
        }
        byte[] raw = out.toByteArray();
        if (raw.length > 4 * 1024 * 1024) raw = java.util.Arrays.copyOf(raw, 4 * 1024 * 1024);
        return new String(raw, "UTF-8");
    }
}
