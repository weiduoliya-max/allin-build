package com.gaeul.allin;

import com.gaeul.allin.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Map;

/**
 * WorkBuddy（国内版 copilot.tencent.com）每日签到。
 *
 * <p>与官方客户端的签到请求完全一致：{@code POST /v2/billing/meter/daily-checkin}，body 为 {@code {}}，
 * 鉴权头与额度查询共用同一套账号头（{@link WorkBuddyPolicy#catalogHeaders}）。
 * 该接口幂等：当天签过会返回“已签到”，重复调用不报错、不扣积分。
 *
 * <p>只有国内版有每日签到体系；国际版 {@code workbuddy-ai}（www.workbuddy.ai）没有，这里直接拒绝。
 */
final class WorkBuddyCheckin {
    static final String PATH = "/v2/billing/meter/daily-checkin";

    static final class Failure extends IOException {
        final String kind;
        final boolean invalidToken;
        Failure(String kind, boolean invalidToken) {
            super("WorkBuddy checkin " + kind);
            this.kind = kind;
            this.invalidToken = invalidToken;
        }
    }

    private WorkBuddyCheckin() {}

    static boolean eligible(JSONObject account) {
        return WorkBuddyAllowance.eligible(account);
    }

    /**
     * 打一次签到。返回 {@code {ok, already, code, msg}}：
     * <ul>
     *   <li>{@code ok}：本次处理成功（含“今天已签到”的幂等成功）</li>
     *   <li>{@code already}：上游表示今天已经签过</li>
     *   <li>{@code code}/{@code msg}：上游原始返回，便于面板展示</li>
     * </ul>
     */
    static JSONObject run(String provider, JSONObject account, WorkBuddyLogin.ConnectionFactory factory) throws Exception {
        if (!"workbuddy".equals(provider)) throw new Failure("region_not_supported", false);
        if (!eligible(account)) throw new Failure("key_not_supported", false);
        String origin = WorkBuddyAuth.origin(provider);
        String key = account.optString("access", account.optString("token", ""));
        if (key.isEmpty()) throw new Failure("sign_in_required", false);
        // 复用 /v3/config 的账号头工厂拿到正确的鉴权头（Bearer / X-Domain / X-User-Id / Agent 头）。
        Map<String, String> headers = WorkBuddyPolicy.catalogHeaders(provider, origin + "/v3/config", key, account);
        if (headers.isEmpty()) throw new Failure("sign_in_required", false);
        HttpURLConnection c = null;
        try {
            c = factory.open(origin + PATH);
            c.setInstanceFollowRedirects(false);
            c.setRequestMethod("POST");
            c.setConnectTimeout(5000);
            c.setReadTimeout(8000);
            for (Map.Entry<String, String> h : headers.entrySet()) c.setRequestProperty(h.getKey(), h.getValue());
            c.setRequestProperty("Content-Type", "application/json");
            c.setDoOutput(true);
            c.setFixedLengthStreamingMode(2);
            try (OutputStream out = c.getOutputStream()) { out.write(new byte[]{'{', '}'}); }
            int status = c.getResponseCode();
            // “今天已签到”上游可能用 4xx 表示，body 仍带 msg，所以非 2xx 也要读 body。
            InputStream in = (status >= 200 && status < 300) ? c.getInputStream() : c.getErrorStream();
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            if (in != null) {
                byte[] buffer = new byte[4096];
                int n;
                long deadline = System.nanoTime() + 5000000000L;
                try {
                    while ((n = in.read(buffer)) != -1) {
                        if (bytes.size() + n > 65536 || System.nanoTime() > deadline) throw new Failure("unavailable", false);
                        bytes.write(buffer, 0, n);
                    }
                } finally { try { in.close(); } catch (IOException ignored) {} }
            }
            String body = new String(bytes.toByteArray(), StandardCharsets.UTF_8);
            JSONObject env = null;
            try { if (!body.trim().isEmpty()) env = new JSONObject(body); } catch (Exception ignored) {}
            int code = env == null ? -1 : env.optInt("code", -1);
            String msg = env == null ? "" : env.optString("msg", env.optString("message", ""));
            String lower = msg.toLowerCase(Locale.ROOT);
            boolean already = msg.contains("已签到") || msg.contains("已签") || lower.contains("already");
            boolean ok = code == 0 || already;
            if (status == 401) throw new Failure("sign_in_required", true);
            if (!ok && (status < 200 || status >= 300)) throw new Failure("http_" + status, false);
            JSONObject result = new JSONObject().put("ok", ok).put("already", already).put("code", code);
            if (!msg.isEmpty()) result.put("msg", bounded(msg));
            return result;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static String bounded(String s) {
        String t = s.replace('\n', ' ').replace('\r', ' ').trim();
        return t.length() > 200 ? t.substring(0, 200) : t;
    }
}
