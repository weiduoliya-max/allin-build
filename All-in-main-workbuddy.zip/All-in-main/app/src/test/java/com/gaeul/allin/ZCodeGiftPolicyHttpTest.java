package com.gaeul.allin;

import java.net.*;
import java.io.*;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.GZIPOutputStream;
import com.gaeul.allin.json.*;

/** Synthetic loopback coverage, Java 8 and Android compatible. */
public final class ZCodeGiftPolicyHttpTest {
    static void check(boolean ok, String why) { if (!ok) throw new AssertionError(why); }
    public static void main(String[] args) throws Exception {
        final ServerSocket server = new ServerSocket(0, 16, InetAddress.getByName("127.0.0.1"));
        final AtomicInteger calls=new AtomicInteger(); final String[] mode={"3012"}, received={""}, sid={""}, title={""}, qid={null}; final long[] now={0}; final java.util.List<String> bodies=java.util.Collections.synchronizedList(new java.util.ArrayList<String>()); final java.util.List<Long> times=java.util.Collections.synchronizedList(new java.util.ArrayList<Long>());
        Thread worker=new Thread(new Runnable() { public void run() {
            while (!server.isClosed()) try {
                Socket socket=server.accept(); socket.setSoTimeout(5000);
                qid[0]=null; title[0]="";
                try {
                    InputStream input=socket.getInputStream(); ByteArrayOutputStream headers=new ByteArrayOutputStream();
                    int state=0, v;
                    while (state<4 && (v=input.read())!=-1) {
                        headers.write(v); state=state==0&&v==13?1:state==1&&v==10?2:state==2&&v==13?3:state==3&&v==10?4:0;
                        if (headers.size()>65536) throw new IOException("headers too large");
                    }
                    int length=0; for (String line:headers.toString("UTF-8").split("\r\n")) {
                        String lower=line.toLowerCase(Locale.ROOT);
                        if (lower.startsWith("content-length:")) length=Integer.parseInt(line.substring(line.indexOf(':')+1).trim());
                        if (lower.startsWith("x-session-id:")) sid[0]=line.substring(line.indexOf(':')+1).trim();
                        if (lower.startsWith("x-title:")) title[0]=line.substring(line.indexOf(':')+1).trim();
                        if (lower.startsWith("x-query-id:")) qid[0]=line.substring(line.indexOf(':')+1).trim();
                    }
                    ByteArrayOutputStream request=new ByteArrayOutputStream();
                    while (length-->0) { v=input.read(); if(v<0) throw new EOFException(); request.write(v); }
                    received[0]=request.toString("UTF-8"); calls.incrementAndGet(); String m=mode[0]; if (m.startsWith("busy")) { bodies.add(received[0]); times.add(System.nanoTime()); }
                    int status=m.equals("redirect")?302:(m.equals("rate") || m.startsWith("busy"))?429:m.equals("ok") || m.equals("slow")?200:405;
                    String text=m.equals("busyusage")?"{\"code\":3008,\"usage\":{\"input_tokens\":1}}":m.startsWith("busy")?"{\"code\":3008}":m.equals("3012")?"{\"code\":3012}":m.equals("edge")?"<html>errors.aliyun.com</html>":m.equals("huge")?new String(new char[70000]).replace('\0','x'):m.equals("ok")?"{\"content\":[]}":m.equals("rate")?"{\"error\":{\"code\":42901,\"message\":\"secret-token prompt\"}}":"plain";
                    byte[] data=text.getBytes("UTF-8"); String extra="";
                    if (m.equals("busygzip") || m.equals("busytruncated")) { ByteArrayOutputStream b=new ByteArrayOutputStream(); GZIPOutputStream z=new GZIPOutputStream(b); z.write("{\"code\":3008}".getBytes("UTF-8")); z.close(); data=b.toByteArray(); if(m.equals("busytruncated")) data=java.util.Arrays.copyOf(data,data.length-4); extra="Content-Encoding: gzip\r\n"; }
                    if (m.equals("gzip")) { ByteArrayOutputStream b=new ByteArrayOutputStream(); GZIPOutputStream z=new GZIPOutputStream(b); z.write("{\"code\":3012}".getBytes("UTF-8")); z.close(); data=b.toByteArray(); extra="Content-Encoding: gzip\r\n"; }
                    if (m.equals("redirect")) extra+="Location: /follow\r\n";
                    if (m.equals("rate")) extra+="Retry-After: 47\r\n";
                    if (m.equals("slow")) { data="ab".getBytes("UTF-8"); extra+="Content-Type: text/event-stream\r\n"; }
                    else extra+="Content-Type: application/json\r\n";
                    OutputStream out=socket.getOutputStream(); out.write(("HTTP/1.1 "+status+" Test\r\n"+extra+"Content-Length: "+data.length+"\r\nConnection: close\r\n\r\n").getBytes("UTF-8"));
                    if (m.equals("slow")) { out.write(data,0,1); out.flush(); try { Thread.sleep(350); } catch (InterruptedException ignored) {} out.write(data,1,1); }
                    else out.write(data);
                    out.flush();
                } finally { socket.close(); }
            } catch (IOException ignored) { }
        }}); worker.setDaemon(true); worker.start();
        try {
            ZCodeGift.setFixtureBase("http://127.0.0.1:"+server.getLocalPort());
            ZCodeGift.setCooldownClockForTests(() -> now[0]);
            JSONObject request=new JSONObject("{\"messages\":[],\"metadata\":{\"user_id\":\"existing\"}}");
            ZCodeGift.Stream first=ZCodeGift.openStream("token","device","zai","m",request,"sess",3000,false);
            check(first.refused && first.status==405 && first.sent,"3012 classification");
            check(new JSONObject(received[0]).getJSONObject("metadata").getString("user_id").equals("existing"),"preserve metadata");
            check(sid[0].equals(ZCodeGift.sessionOf("sess","device")),"session header");
            ZCodeGift.Stream held=ZCodeGift.openStream("token","device","zai","m",request,"sess",3000,false);
            check(held.observed && "local_cooldown".equals(held.source),"cooldown source observed");
            check(held.held && held.status==429 && calls.get()==1 && !held.sent,"hold before network");
            check(ZCodeGift.hold("token","device",null)!=null,"hold helper reflects cooldown");
            now[0]+=ZCodeRefusalPolicy.HOLD_MILLIS; mode[0]="plain";
            ZCodeGift.Stream bare=ZCodeGift.openStream("token","device","zai","m",request,"sess",3000,false);
            check(!bare.refused && bare.classification==ZCodeRefusalPolicy.Kind.UNKNOWN,"bare 405");
            ZCodeGift.openStream("token","device","zai","m",request,"sess",3000,false); check(calls.get()==3,"bare no hold");
            mode[0]="gzip"; check(ZCodeGift.openStream("token","device","zai","m",request,"sess",3000,false).refused,"gzip");
            ZCodeGift.resetCooldownForTests(); mode[0]="huge"; check(!ZCodeGift.openStream("token","device","zai","m",request,"sess",3000,false).refused,"truncated");
            mode[0]="redirect"; int before=calls.get(); check(ZCodeGift.openStream("token","device","zai","m",request,"sess",3000,false).status==302 && calls.get()==before+1,"redirect");
            mode[0]="rate"; int beforeRate=calls.get();
            ZCodeGift.Stream rate=ZCodeGift.openStream("token","device","zai","m",request,"sess",3000,false);
            check("42901".equals(rate.businessCode) && "upstream".equals(rate.source) && rate.observed,"safe numeric code and upstream source");
            check(rate.status==429 && rate.sent && rate.retryAfterMillis==47000 && !rate.refused && !rate.edge
                    && !rate.held && rate.classification==ZCodeRefusalPolicy.Kind.NONE && calls.get()==beforeRate+1,"plain 429 retry-after, no retries or refusal");
            check(ZCodeGift.hold("token","device",null)==null,"plain 429 creates no refusal hold");
            mode[0]="busy"; bodies.clear(); times.clear();
            ZCodeGift.Stream busy=ZCodeGift.openStream("token","device","zai","m",request,"sess",5000,true);
            check(busy.status==429 && busy.sends==3 && "3008".equals(busy.busyCode),"busy three sends");
            check(bodies.size()==3 && bodies.get(0).equals(bodies.get(1)) && bodies.get(1).equals(bodies.get(2)),"retry bytes identical");
            check((times.get(1)-times.get(0))/1000000>=900 && (times.get(2)-times.get(1))/1000000>=1900,"real backoff");
            mode[0]="busygzip"; RequestContext gzipBudget=new RequestContext("gift",NetworkPolicy.capture(),1500);
            int gzipBefore=calls.get(); ZCodeGift.Stream gzipBusy=ZCodeGift.openStream("token","device","zai","m",request,"sess",5000,true,gzipBudget);
            check(gzipBusy.sends==2 && calls.get()==gzipBefore+2 && "3008".equals(gzipBusy.busyCode),"complete gzip retried"); gzipBudget.close();
            mode[0]="busytruncated"; int truncatedBefore=calls.get();
            ZCodeGift.Stream truncatedBusy=ZCodeGift.openStream("token","device","zai","m",request,"sess",5000,true);
            check(truncatedBusy.sends==1 && calls.get()==truncatedBefore+1 && truncatedBusy.status<0 && truncatedBusy.transportKind!=null,"truncated gzip is unknown, never retried");
            mode[0]="busyusage"; int usageBefore=calls.get();
            ZCodeGift.Stream usage=ZCodeGift.openStream("token","device","zai","m",request,"sess",5000,true);
            check(usage.sends==1 && calls.get()==usageBefore+1 && usage.errorBody.contains("usage"),"busy usage is never replayed");
            mode[0]="busy"; RequestContext shortBudget=new RequestContext("gift",NetworkPolicy.capture(),500);
            int budgetBefore=calls.get(); ZCodeGift.Stream budget=ZCodeGift.openStream("token","device","zai","m",request,"sess",5000,true,shortBudget);
            check(budget.status==429 && calls.get()==budgetBefore+1,"insufficient budget preserves 429"); shortBudget.close();
            mode[0]="edge"; check(ZCodeGift.openStream("token","device","zai","m",request,"sess",3000,false).edge,"edge");
            check(ZCodeGift.openStream("other","device","zai","m",request,"sess",3000,false).held,"edge network scope");
            ZCodeGift.resetCooldownForTests(); mode[0]="ok"; JSONObject empty=new JSONObject("{\"messages\":[]}");
            ZCodeGift.Stream ok=ZCodeGift.openStream("token","device","zai","m",empty,"sess",3000,false);
            JSONObject uid=new JSONObject(new JSONObject(received[0]).getJSONObject("metadata").getString("user_id"));
            check(uid.getString("session_id").equals(sid[0]),"generated session matches"); ok.is.close();
            for (String metadata : new String[]{"null", "[]", "\"opaque\"", "{\"user_id\":null,\"trace\":7}"}) {
                JSONObject original=new JSONObject("{\"messages\":[],\"metadata\":"+metadata+"}");
                ZCodeGift.Stream dressed=ZCodeGift.openStream("token","device","zai","m",original,"sess",3000,true);
                JSONObject actual=new JSONObject(received[0]).getJSONObject("metadata");
                JSONObject bound=new JSONObject(actual.getString("user_id"));
                check(bound.getString("device_id").equals("device")&&bound.getString("session_id").equals(sid[0]),"dressed gift metadata matches authenticated device and header session");
                if(original.optJSONObject("metadata")!=null&&original.getJSONObject("metadata").has("trace"))check(actual.getInt("trace")==7,"other metadata retained");
                dressed.is.close();
            }
            // ---- 3.17.2 的 X-Title 与 x-query-id：全部走回环夹具，不对真网 ----
            mode[0]="ok"; String turnSid=ZCodeGift.sessionOf("sess","device");
            JSONObject ask=new JSONObject("{\"messages\":[{\"role\":\"user\",\"content\":[{\"type\":\"text\",\"text\":\"fix it\"}]}]}");
            ZCodeGift.Stream turnZ=ZCodeGift.openStream("token","device","zai","m",ask,"sess",3000,true);
            check("Z Code@electron".equals(title[0]),"x-title is Z Code@electron");
            String turnId=qid[0];
            check(turnId!=null && turnId.equals(ZCodeGift.queryOf(ask.toString(),turnSid)),"x-query-id names this turn");
            check(turnId.equals(ZCodeGift.uuidOf("zcode-query\0"+turnSid+"\0"+1)),"x-query-id seed is session and turn count");
            check(turnId.matches("(?i)^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$"),"x-query-id is a v4 shaped uuid");
            check(!turnId.contains("fix") && turnId.length()==36,"x-query-id carries no query text");
            check(!ZCodeGift.queryOf(ZCodeGift.dress(new JSONObject(ask.toString()),"zai","m","device",turnSid).toString(),turnSid).equals(turnId),
                    "the name comes from the agent's ask, not the dressed body");
            turnZ.is.close();
            JSONObject continued=new JSONObject("{\"messages\":[{\"role\":\"user\",\"content\":[{\"type\":\"text\",\"text\":\"fix it\"}]},"
                    +"{\"role\":\"assistant\",\"content\":[{\"type\":\"tool_use\",\"id\":\"t1\",\"name\":\"Bash\",\"input\":{}}]},"
                    +"{\"role\":\"user\",\"content\":[{\"type\":\"tool_result\",\"tool_use_id\":\"t1\",\"content\":\"a\"}]}]}");
            ZCodeGift.Stream nextZ=ZCodeGift.openStream("token","device","zai","m",continued,"sess",3000,true);
            check(turnId.equals(qid[0]) && nextZ.sends==1,"tool results keep the turn's x-query-id"); nextZ.is.close();
            JSONObject asked=new JSONObject("{\"messages\":[{\"role\":\"user\",\"content\":[{\"type\":\"text\",\"text\":\"fix it\"}]},"
                    +"{\"role\":\"assistant\",\"content\":\"done\"},{\"role\":\"user\",\"content\":\"thanks\"}]}");
            ZCodeGift.Stream secondZ=ZCodeGift.openStream("token","device","zai","m",asked,"sess",3000,true);
            check(qid[0]!=null && !qid[0].equals(turnId),"the next user message is a new x-query-id"); secondZ.is.close();
            ZCodeGift.Stream otherZ=ZCodeGift.openStream("token","device","zai","m",ask,"other-sess",3000,true);
            check(qid[0]!=null && !qid[0].equals(turnId),"another session is another x-query-id"); otherZ.is.close();
            JSONObject resultsOnly=new JSONObject("{\"messages\":[{\"role\":\"user\",\"content\":[{\"type\":\"tool_result\",\"tool_use_id\":\"t1\",\"content\":\"a\"}]}]}");
            ZCodeGift.Stream noneZ=ZCodeGift.openStream("token","device","zai","m",resultsOnly,"sess",3000,true);
            check(qid[0]==null,"tool results alone send no x-query-id"); noneZ.is.close();
            check(ZCodeGift.queryOf(resultsOnly.toString(),turnSid).isEmpty(),"no user text, no query id");
            check(ZCodeGift.queryOf("{","s1").isEmpty(),"an unreadable body sends none");
            check(ZCodeGift.queryOf("{\"messages\":\"none\"}","s1").isEmpty(),"messages that is no array sends none");
            check(ZCodeGift.queryOf("{\"messages\":[{\"role\":\"assistant\",\"content\":\"hi\"}]}","s1").isEmpty(),"the model's own words are no query");
            check(ZCodeGift.queryOf("{\"messages\":[{\"role\":\"user\",\"content\":\"   \"}]}","s1").isEmpty(),"a blank ask sends none");
            check(ZCodeGift.queryOf("{\"messages\":[{\"role\":\"user\",\"content\":\"\u00a0\"}]}","s1").isEmpty(),"a non-breaking space is no ask");
            check(ZCodeGift.queryOf("{\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}]}","s1")
                    .equals(ZCodeGift.uuidOf("zcode-query\0s1\0"+"1")),"a plain string ask counts");
            check(!ZCodeGift.queryOf(ask.toString(),"other").equals(turnId),"the session is part of the name");
            JSONObject unusual=ZCodeGift.dress(new JSONObject("{\"messages\":[]}"),"zai","m","device\"quoted","session");
            check(new JSONObject(unusual.getJSONObject("metadata").getString("user_id")).getString("device_id").equals("device\"quoted"),"escaped device id");
            mode[0]="slow"; RequestContext deadline=new RequestContext("gift",NetworkPolicy.capture(),150);
            ZCodeGift.Stream slow=ZCodeGift.openStream("token","device","zai","m",empty,"sess",3000,false,deadline);
            check(slow.status==200,"slow response opened"); boolean expired=false;
            try { while(slow.is.read()!=-1) {} } catch(IOException expected) { expired=true; }
            check(expired && deadline.remainingMillis()==0,"stream enforces deadline"); deadline.close();
            RequestContext cancelled=new RequestContext("gift",NetworkPolicy.capture(),3000); cancelled.cancel("test");
            int countBeforeCancel=calls.get(); ZCodeGift.Stream stopped=ZCodeGift.openStream("token","device","zai","m",empty,"sess",3000,false,cancelled);
            check(stopped.status==-1 && !stopped.sent && calls.get()==countBeforeCancel,"cancel before send");
            check(ZCodeGift.hold("token","device",null)==null,"hold helper clear");
            System.out.println("ZCodeGiftPolicyHttpTest PASS");
        } finally { ZCodeGift.setFixtureBase(null); ZCodeGift.resetCooldownForTests(); server.close(); }
    }
}
