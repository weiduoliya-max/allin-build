package com.gaeul.allin;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.GZIPOutputStream;
import com.gaeul.allin.json.JSONObject;
public class TraeAuthHttpTest {
 static final String CRLF=new String(new char[]{13,10});
 static void ok(boolean v,String m){if(!v)throw new AssertionError(m);}
 static int call(int port,String request)throws Exception {try(Socket s=new Socket("127.0.0.1",port)){s.setSoTimeout(5000);s.getOutputStream().write(request.getBytes("UTF-8"));s.getOutputStream().flush();String line=new BufferedReader(new InputStreamReader(s.getInputStream(),"UTF-8")).readLine();return Integer.parseInt(line.split(" ")[1]);}}
 static URL callback(TraeAuth.Flow f)throws Exception{String q=new URL(f.url).getQuery();for(String p:q.split("&")){String[] x=p.split("=",2);if(x[0].equals("auth_callback_url"))return new URL(URLDecoder.decode(x[1],"UTF-8"));}throw new AssertionError();}
 static int port(TraeAuth.Flow f)throws Exception{return callback(f).getPort();}
 static String callbackPath(TraeAuth.Flow f)throws Exception{return callback(f).getFile()+"?loginTraceID="+enc(f.flowId);}
 static final class Fixture implements AutoCloseable {
  final ServerSocket ss=new ServerSocket(0,10,InetAddress.getByName("127.0.0.1")); volatile String mode="gzip"; final AtomicInteger count=new AtomicInteger(); final CountDownLatch arrived=new CountDownLatch(1); volatile String lastHeaders=""; final Thread thread;
  Fixture()throws Exception{TraeAuth.setFixtureBase("http://127.0.0.1:"+ss.getLocalPort());thread=new Thread(()->{while(!ss.isClosed())try{Socket s=ss.accept();count.incrementAndGet();new Thread(()->serve(s)).start();}catch(Exception e){break;}});thread.setDaemon(true);thread.start();}
  void serve(Socket s){try(Socket c=s){c.setSoTimeout(3000);InputStream in=c.getInputStream(); ByteArrayOutputStream h=new ByteArrayOutputStream();int x;while((x=in.read())>=0){h.write(x);byte[] b=h.toByteArray();int n=b.length;if(n>=4&&b[n-4]==13&&b[n-3]==10&&b[n-2]==13&&b[n-1]==10)break;}String raw=h.toString("UTF-8");lastHeaders=raw;int len=0;for(String line:raw.split("\r\n"))if(line.toLowerCase().startsWith("content-length:"))len=Integer.parseInt(line.substring(15).trim());while(len-->0&&in.read()!=-1){} arrived.countDown();String m=mode;if(m.equals("hang")){Thread.sleep(4000);return;} if(m.equals("drop"))return;
   if(m.equals("slow")){OutputStream o=c.getOutputStream();o.write("HTTP/1.1 200 OK\r\nContent-Length: 100\r\n\r\n".getBytes(StandardCharsets.US_ASCII));o.flush();for(int i=0;i<100;i++){o.write(32);o.flush();Thread.sleep(100);}return;}byte[] b;String extra="";int status=200;
   if(m.equals("gzip")){ByteArrayOutputStream o=new ByteArrayOutputStream();try(GZIPOutputStream g=new GZIPOutputStream(o)){g.write("{\"ok\":true}".getBytes(StandardCharsets.UTF_8));}b=o.toByteArray();extra="Content-Encoding: gzip\r\n";}
   else if(m.equals("large")){b=new byte[2*1024*1024+1];}
   else if(m.equals("reject")){status=400;b="{\"ResponseMetadata\":{\"Error\":{\"Code\":\"denied\"}}}".getBytes(StandardCharsets.UTF_8);mode="success";}
   else if(m.equals("denied")){status=403;b="{\"ResponseMetadata\":{\"Error\":{\"Code\":\"10101\",\"Message\":\"synthetic-private-reason\"}}}".getBytes(StandardCharsets.UTF_8);}
   else if(m.equals("badgateway")){status=502;b="<html>synthetic-private-reason</html>".getBytes(StandardCharsets.UTF_8);}
   else if(m.equals("oddcode")){status=403;b="{\"code\":\"synthetic-private-reason\"}".getBytes(StandardCharsets.UTF_8);}
   else if(m.equals("redirect")){status=302;b=new byte[0];extra="Location: http://127.0.0.1:"+ss.getLocalPort()+"/redirected\r\n";}
   else {b="{\"Result\":{\"Token\":\"new\",\"RefreshToken\":\"newrefresh\",\"TokenExpireAt\":\"2026-11-06T01:02:03Z\"}}".getBytes(StandardCharsets.UTF_8);}
   OutputStream out=c.getOutputStream();out.write(("HTTP/1.1 "+status+" OK\r\nContent-Length: "+b.length+"\r\n"+extra+"Connection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));out.write(b);out.flush();}catch(Exception ignored){}}
  public void close()throws Exception{ss.close();TraeAuth.setFixtureBase(null);thread.join(1000);}
 }
 static JSONObject account()throws Exception{JSONObject a=TraeDevice.create();a.put("token","old");a.put("refresh","refresh");a.put("uid","123");return a;}
 static String enc(String s)throws Exception{return URLEncoder.encode(s,"UTF-8");}
 static String response(int port,String request)throws Exception {
  try(Socket s=new Socket("127.0.0.1",port)){
   s.setSoTimeout(10000);s.getOutputStream().write(request.getBytes(StandardCharsets.UTF_8));s.getOutputStream().flush();
   InputStream in=s.getInputStream();ByteArrayOutputStream h=new ByteArrayOutputStream();int x,match=0;int[] end={13,10,13,10};
   while(h.size()<32768&&(x=in.read())>=0){h.write(x);match=x==end[match]?match+1:x==13?1:0;if(match==4)break;}
   ok(match==4,"complete callback headers");String headers=h.toString("UTF-8");int length=-1;
   for(String line:headers.split(CRLF))if(line.toLowerCase().startsWith("content-length:"))length=Integer.parseInt(line.substring(15).trim());
   ok(length>=0&&length<32768,"bounded callback body");byte[] b=new byte[length];int n=0;
   while(n<length){int read=in.read(b,n,length-n);ok(read>0,"complete callback body");n+=read;}
   return headers+new String(b,StandardCharsets.UTF_8);
  }
 }
 static void diagnosticCases()throws Exception {
  ok(TraeAuth.consumerAuthHost("https://API.TRAE.COM.CN:443/").equals("https://api.trae.com.cn"),"canonical official auth host");
  try{TraeAuth.consumerAuthHost("https://api.trae.cn.evil.example");throw new AssertionError("host accepted");}catch(TraeAuth.Failure expected){}
  ok(!TraeAuth.bindingFailureMessage(new IOException("synthetic-private-reason")).contains("synthetic-private-reason"),"exception message redacted");
  try(Fixture fixture=new Fixture()){
   for(String mode:new String[]{"denied","badgateway","oddcode"}){
    fixture.mode=mode;int before=fixture.count.get();TraeAuth.Flow f=TraeAuth.startLogin();
    try {
     int p=port(f);String path=callbackPath(f)+"&userJwt="+enc("{\"Token\":\"synthetic-token\",\"RefreshToken\":\"synthetic-refresh\"}")+"&userInfo="+enc("{\"UserID\":\"synthetic-user\"}");
     String page=response(p,"GET "+path+" HTTP/1.1"+CRLF+"Host: 127.0.0.1:"+p+CRLF+CRLF);
     ok(f.status.equals("failed")&&f.takeResult()==null,"failed bind never becomes account");
     ok(page.contains("name=\"viewport\"")&&page.contains("Content-Type: text/html"),"mobile-readable callback");
     ok(page.contains("Referrer-Policy: no-referrer")&&page.contains("default-src 'none'"),"private callback page");
     ok(!page.contains("synthetic-")&&!f.view().toString().contains("synthetic-"),"no upstream body or credential in diagnostics");
     String want=mode.equals("denied")?"HTTP_403_CODE_10101":mode.equals("badgateway")?"HTTP_502_NON_JSON":"HTTP_403_CODE_OTHER";
     ok(page.contains(want)&&f.errorCode.contains(want),"specific safe diagnostic: "+mode);
     ok(fixture.count.get()-before==(mode.equals("badgateway")?1:3),"unknown outcome never retried; definitive refusals only permit read-only verification");
    }finally{f.close();}
   }
  }
 }
 public static void main(String[] args)throws Exception {
  diagnosticCases();
  for(String alias:new String[]{"https://api.trae.cn","https://api.trae.com.cn","api.trae.com.cn","https://api.trae.com.cn/"})ok(TraeAuth.consumerCallbackHost(alias,true),"consumer auth alias");
  for(String hostile:new String[]{"https://api.trae.com.cn.evil.example","https://api.trae.com.cn@evil.example","http://api.trae.com.cn","https://api.trae.com.cn:8443","https://api.trae.com.cn/path","https://api.trae.com.cn?x=1"})ok(!TraeAuth.consumerCallbackHost(hostile,true),"reject untrusted alias");
  ok(TraeAuth.expiry("2026-11-06T01:02:03Z")==1793926923000L,"ISO");ok(TraeAuth.expiry("2026-11-06T09:02:03+08:00")==1793926923000L,"offset");ok(TraeAuth.expiry("1793926923")==1793926923000L,"seconds");ok(TraeAuth.expiry("1793926923000")==1793926923000L,"milliseconds");
  String jwtPayload=TraeDevice.b64("{\"exp\":1793926923}".getBytes(StandardCharsets.UTF_8)).replace('=',' ').trim().replace('+','-').replace('/','_');ok(TraeAuth.tokenExpiry(new JSONObject(),"a."+jwtPayload+".b")==1793926923000L,"JWT fallback");
  TraeAuth.Flow f=TraeAuth.startLogin();try{String knownPattern="^http://127\\.0\\.0\\.1:(\\d+)/authorize$"; ok(callback(f).toString().matches(knownPattern) && !(callback(f).toString()+"?source=fixture").matches(knownPattern) && callback(f).getQuery()==null,"official authorization script callback grammar"); String trace=null; for(String part:new URL(f.url).getQuery().split("&")){String[] pair=part.split("=",2); if(pair[0].equals("login_trace_id")) trace=URLDecoder.decode(pair[1],"UTF-8");} ok(f.flowId.equals(trace),"authorization trace is callback nonce");int p=port(f);String host="Host: 127.0.0.1:"+p+"\r\n";ok(call(p,"OPTIONS /authorize HTTP/1.1\r\n"+host+"Origin: https://www.trae.cn\r\n\r\n")==204,"preflight");ok(call(p,"GET /authorize HTTP/1.1\r\n"+host+"Origin: https://evil.example\r\n\r\n")==403,"origin");ok(call(p,"GET /authorize?userJwt=x&userJwt=y HTTP/1.1\r\n"+host+"\r\n")==400,"duplicate");
   ok(call(p,"GET /authorize?error=x HTTP/1.1\r\n"+host+"\r\n")==403,"missing state");
   ok(call(p,"GET /authorize?local_state=wrong&error=x HTTP/1.1\r\n"+host+"\r\n")==403,"wrong state");
   ok(call(p,"GET /authorize?loginTraceID=wrong&error=x HTTP/1.1\r\n"+host+"\r\n")==403,"wrong trace"); ok(call(p,"GET "+callbackPath(f)+"&login_trace_id="+enc(f.flowId)+"&error=x HTTP/1.1\r\n"+host+"\r\n")==403,"two trace aliases rejected");}finally{f.close();}
  try(Fixture fixture=new Fixture()){JSONObject a=account();ok(TraeAuth.modelRequest(a,"/api/ide/v1/get_detail_param",new JSONObject(),null,null).optBoolean("ok"),"gzip");fixture.mode="gzip";TraeAuth.checkin(a,null,null,false);String hdr=fixture.lastHeaders.toLowerCase();ok(hdr.contains("x-app-id:")&&hdr.contains("x-machine-id:")&&hdr.contains("x-ide-version:")&&hdr.contains("user-agent:")&&hdr.contains("accept: application/json"),"checkin headers");
   for(int attempt=0;attempt<4;attempt++){fixture.mode="slow";RequestContext deadline=new RequestContext("test",NetworkPolicy.capture(),450);long start=System.nanoTime();try{TraeAuth.request(a,"/trae/api/test","GET",null,null,deadline);throw new AssertionError("slow");}catch(TraeAuth.Failure e){ok(e.code.equals("outcome_unknown"),"slow deadline");}finally{deadline.close();}long elapsed=TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-start);System.out.println("slow deadline "+attempt+": "+elapsed+"ms");ok(elapsed<2500,"slow deadline bounded: "+elapsed);}
   fixture.mode="hang";RequestContext afterSlow=new RequestContext("test",NetworkPolicy.capture(),450);long afterStart=System.nanoTime();try{TraeAuth.request(a,"/trae/api/test","GET",null,null,afterSlow);throw new AssertionError("hang");}catch(TraeAuth.Failure e){ok(e.code.equals("outcome_unknown"),"hang deadline");}finally{afterSlow.close();}long afterElapsed=TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-afterStart);System.out.println("subsequent deadline: "+afterElapsed+"ms");ok(afterElapsed<2500,"subsequent deadline bounded: "+afterElapsed);
   fixture.mode="large";try{TraeAuth.request(a,"/trae/api/test","GET",null,null,null);throw new AssertionError("large");}catch(TraeAuth.Failure e){ok(e.code.equals("response_too_large"),"large code");}fixture.mode="redirect";int before=fixture.count.get();try{TraeAuth.request(a,"/trae/api/test","GET",null,null,null);throw new AssertionError("redirect");}catch(TraeAuth.Failure e){ok(e.code.equals("http_302"),"redirect code");}ok(fixture.count.get()==before+1,"redirect followed");fixture.mode="drop";before=fixture.count.get();try{TraeAuth.refresh(a,null,null);throw new AssertionError("unknown");}catch(TraeAuth.Failure e){ok(e.code.equals("outcome_unknown"),"unknown code");}ok(fixture.count.get()==before+1,"unknown retried");fixture.mode="reject";before=fixture.count.get();ok(TraeAuth.refresh(a,null,null).optBoolean("bound") && fixture.count.get()==before+2,"explicit rejection retry");fixture.mode="success";
   TraeAuth.Flow login=TraeAuth.startLogin();try{int p=port(login);String jwt=enc("{\"Token\":\"old\",\"RefreshToken\":\"refresh\"}");String info=enc("{\"UserID\":\"123\",\"Host\":\"https://api.trae.com.cn\"}");ok(call(p,"GET "+callbackPath(login)+"&state=browser-state&userJwt="+jwt+"&userInfo="+info+" HTTP/1.1\r\nHost: 127.0.0.1:"+p+"\r\n\r\n")==200,"browser callback without origin");JSONObject r=login.takeResult();ok(r!=null&&r.optBoolean("bound")&&login.takeResult()==null,"one shot");}finally{login.close();}
  }
  try(Fixture fixture=new Fixture()){fixture.mode="drop";TraeAuth.Flow login=TraeAuth.startLogin();try{int p=port(login);String jwt=enc("{\"Token\":\"old\",\"RefreshToken\":\"refresh\"}"),info=enc("{\"Host\":\"https://api.trae.com.cn\"}");ok(call(p,"GET "+callbackPath(login)+"&userJwt="+jwt+"&userInfo="+info+" HTTP/1.1\r\nHost: 127.0.0.1:"+p+"\r\n\r\n")==200,"failure callback");ok(login.status.equals("failed")&&login.takeResult()==null&&login.error.contains("结果未知"),"failure no result");ok(fixture.count.get()==1,"binding unknown no retry");}finally{login.close();}}
  try(Fixture fixture=new Fixture()){fixture.mode="hang";TraeAuth.Flow login=TraeAuth.startLogin();int p=port(login);Thread client=new Thread(()->{try{String jwt=enc("{\"Token\":\"old\",\"RefreshToken\":\"refresh\"}"),info=enc("{\"Host\":\"www.trae.cn\"}");call(p,"GET "+callbackPath(login)+"&userJwt="+jwt+"&userInfo="+info+" HTTP/1.1\r\nHost: 127.0.0.1:"+p+"\r\n\r\n");}catch(Exception ignored){}});client.start();ok(fixture.arrived.await(4,TimeUnit.SECONDS),"binding started");login.close();client.join(2500);ok(!client.isAlive(),"close aborts callback");ok(login.status.equals("closed")&&login.takeResult()==null,"closed result");}
  System.out.println("TraeAuthHttpTest OK");
 }
}
