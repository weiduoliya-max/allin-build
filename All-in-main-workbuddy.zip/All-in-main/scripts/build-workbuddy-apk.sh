#!/usr/bin/env bash
# 本地一条命令出 APK（Linux / macOS / Termux）。
# 前置：JDK 17+、Android SDK（platforms;android-37.0）、网络能拉 Maven 依赖。
set -euo pipefail

cd "$(dirname "$0")/.."

echo "== 环境检查 =="
command -v java >/dev/null || { echo "缺 java：装 JDK 17 或 21（Termux: pkg install openjdk-17）"; exit 1; }
java -version 2>&1 | head -1

if [ -z "${ANDROID_HOME:-}" ] && [ -z "${ANDROID_SDK_ROOT:-}" ]; then
  for guess in "$HOME/Android/Sdk" "/usr/lib/android-sdk" "$PREFIX/opt/android-sdk"; do
    [ -d "$guess" ] && export ANDROID_HOME="$guess" && break
  done
fi

if [ -z "${ANDROID_HOME:-}" ] || [ ! -d "${ANDROID_HOME}/platforms" ]; then
  cat <<'TIP'
找不到 Android SDK。
  电脑：装 Android Studio，或下载 commandline-tools 后执行
        sdkmanager --install "platforms;android-37.0"
        再 export ANDROID_HOME=/path/to/sdk
  Termux：pkg install openjdk-17
        pkg install android-sdk  # 若仓库无此包，用 commandline-tools + sdkmanager
TIP
  exit 1
fi
echo "ANDROID_HOME=${ANDROID_HOME}"

KEYSTORE="${MAGPIE_KEYSTORE:-$PWD/tools/magpie.keystore}"
if [ ! -f "$KEYSTORE" ]; then
  echo "== 生成签名用 keystore: $KEYSTORE =="
  mkdir -p "$(dirname "$KEYSTORE")"
  keytool -genkeypair -v -keystore "$KEYSTORE" -alias magpie \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass "${MAGPIE_KEYSTORE_PASS:-magpie123}" \
    -keypass "${MAGPIE_KEY_PASS:-${MAGPIE_KEYSTORE_PASS:-magpie123}}" \
    -dname "CN=FJ, O=FJ"
fi

export MAGPIE_KEYSTORE="$KEYSTORE"
export MAGPIE_KEYSTORE_PASS="${MAGPIE_KEYSTORE_PASS:-magpie123}"
export MAGPIE_KEY_ALIAS="${MAGPIE_KEY_ALIAS:-magpie}"
export MAGPIE_KEY_PASS="${MAGPIE_KEY_PASS:-$MAGPIE_KEYSTORE_PASS}"

echo "== 编译 release =="
./gradlew assembleRelease --no-daemon

APK=$(ls -1 app/build/outputs/apk/release/*.apk 2>/dev/null | head -1)
echo
echo "产物：$APK"
ls -lh "$APK"
